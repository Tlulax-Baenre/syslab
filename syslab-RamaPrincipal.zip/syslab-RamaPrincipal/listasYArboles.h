#ifndef LISTASYARBOLES_H_INCLUDED
#define LISTASYARBOLES_H_INCLUDED
#include "Usuarios.h"

typedef struct
{
    Practica unaPractica;
    struct nodoLista* siguiente;
}nodoLista;

typedef struct
{
    IngresoLab unIngreso;
    struct nodoLista* lista;
}celda;

typedef struct NodoArbol {
    Paciente paciente;
    struct NodoArbol *izquierdo;
    struct NodoArbol *derecho;
} NodoArbol;

// Definici�n de la estructura para el �rbol binario
typedef struct {
    NodoArbol *raiz;
} ArbolBinario;

NodoArbol* crearNodo(Paciente unPaciente);
NodoArbol* inicializarArbol() ;
nodoLista* inicializarLista() ;

#endif // LISTASYARBOLES_H_INCLUDED
